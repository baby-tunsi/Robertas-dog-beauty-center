from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import logging
import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional

import bcrypt
import jwt
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr, ConfigDict


# ---------- Setup ----------
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_ALGORITHM = "HS256"
FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:3000")

# Default hours shown to public clients (staff can manually book any time)
DEFAULT_HOURS = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"]

app = FastAPI(title="Roberta's Beauty Dog Center API")
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ---------- Password / JWT helpers ----------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def get_jwt_secret() -> str:
    return os.environ["JWT_SECRET"]


def create_access_token(user_id: str, email: str, token_version: int = 0) -> str:
    payload = {
        "sub": user_id, "email": email, "ver": token_version,
        "exp": datetime.now(timezone.utc) + timedelta(hours=8),
        "type": "access",
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def set_auth_cookie(response: Response, token: str):
    response.set_cookie(
        key="access_token", value=token, httponly=True, secure=True,
        samesite="none", max_age=8 * 3600, path="/",
    )


# ---------- Models ----------
class UserPublic(BaseModel):
    id: str
    email: EmailStr
    name: str
    role: str


class LoginInput(BaseModel):
    email: EmailStr
    password: str


class CodeLoginInput(BaseModel):
    code: str = Field(min_length=1, max_length=32)


class BookingCreate(BaseModel):
    first_name: str = Field(min_length=1, max_length=60)
    last_name: str = Field(min_length=1, max_length=60)
    phone: str = Field(min_length=5, max_length=30)
    dog_name: str = Field(min_length=1, max_length=60)
    dog_breed: str = Field(min_length=1, max_length=80)
    dog_size: str = Field(min_length=1, max_length=20)
    service_id: str
    date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    time: str = Field(pattern=r"^\d{2}:\d{2}$")
    time_preference: str = Field(min_length=1, max_length=120)
    notes: str = Field(min_length=1, max_length=500)


class Booking(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    first_name: str
    last_name: str
    phone: str
    dog_name: Optional[str] = None
    dog_breed: Optional[str] = None
    dog_size: Optional[str] = None
    service_id: str
    service_name: str
    preferred_date: str
    preferred_time: str
    time_preference: Optional[str] = None
    notes: Optional[str] = None
    status: str
    source: str = "online"  # online / manual
    created_at: str
    confirmed_at: Optional[str] = None
    verified_by: Optional[str] = None
    staff_note: Optional[str] = None


class StatusUpdate(BaseModel):
    staff_note: Optional[str] = Field(default=None, max_length=500)


class ManualBookingCreate(BaseModel):
    first_name: str = Field(min_length=1, max_length=60)
    last_name: str = Field(min_length=1, max_length=60)
    phone: str = Field(min_length=5, max_length=30)
    dog_name: Optional[str] = Field(default=None, max_length=60)
    dog_breed: Optional[str] = Field(default=None, max_length=80)
    dog_size: Optional[str] = Field(default=None, max_length=20)
    service_id: str
    date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    time: str = Field(pattern=r"^\d{2}:\d{2}$")
    notes: Optional[str] = Field(default=None, max_length=500)


# ---------- Services catalog ----------
SERVICES = [
    {"id": "bagno", "name": "Bagno & Asciugatura", "price_min": 25, "price_max": 45,
     "duration": "45-75 min",
     "description": "Bagno con shampoo delicati specifici per il pelo, asciugatura professionale e spazzolatura finale."},
    {"id": "taglio", "name": "Taglio & Tosatura", "price_min": 35, "price_max": 65,
     "duration": "60-90 min",
     "description": "Taglio su misura secondo lo standard di razza o secondo le preferenze del proprietario."},
    {"id": "unghie", "name": "Taglio Unghie", "price_min": 10, "price_max": 15,
     "duration": "15 min",
     "description": "Taglio e limatura delle unghie in totale sicurezza, evitando stress al tuo amico."},
    {"id": "orecchie", "name": "Pulizia Orecchie & Denti", "price_min": 15, "price_max": 25,
     "duration": "20 min",
     "description": "Pulizia profonda delle orecchie e igiene dentale con prodotti veterinari."},
    {"id": "spa", "name": "Spa & Trattamenti Extra", "price_min": 40, "price_max": 80,
     "duration": "60-90 min",
     "description": "Impacchi al fango, maschere emollienti, aromaterapia e coccole in totale relax."},
]
SERVICE_MAP = {s["id"]: s for s in SERVICES}


# ---------- Auth dependency ----------
async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Non autenticato")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Token non valido")
        user = await db.users.find_one({"id": payload["sub"]})
        if not user:
            raise HTTPException(status_code=401, detail="Utente non trovato")
        if payload.get("ver", 0) != user.get("token_version", 0):
            raise HTTPException(status_code=401, detail="Sessione scaduta")
        user.pop("password_hash", None)
        user.pop("_id", None)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token scaduto")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token non valido")


# ---------- Availability helpers ----------
async def _is_time_taken(date: str, time: str) -> bool:
    """A time is taken if there is any pending or confirmed booking at that datetime."""
    existing = await db.bookings.find_one({
        "preferred_date": date,
        "preferred_time": time,
        "status": {"$in": ["pending", "confirmed"]},
    })
    return existing is not None


# ---------- Auth routes ----------
@api_router.post("/auth/login", response_model=UserPublic)
async def login(payload: LoginInput, response: Response):
    email = payload.email.lower().strip()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenziali non valide")
    token = create_access_token(user["id"], user["email"], user.get("token_version", 0))
    set_auth_cookie(response, token)
    return UserPublic(id=user["id"], email=user["email"], name=user["name"], role=user["role"])


@api_router.post("/auth/code-login", response_model=UserPublic)
async def code_login(payload: CodeLoginInput, response: Response):
    expected = os.environ.get("STAFF_ACCESS_CODE", "").strip()
    if not expected or payload.code.strip() != expected:
        raise HTTPException(status_code=401, detail="Codice non valido")
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@example.com").lower()
    user = await db.users.find_one({"email": admin_email})
    if not user:
        raise HTTPException(status_code=500, detail="Account staff non configurato")
    token = create_access_token(user["id"], user["email"], user.get("token_version", 0))
    set_auth_cookie(response, token)
    return UserPublic(id=user["id"], email=user["email"], name=user["name"], role=user["role"])


@api_router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    return {"success": True}


@api_router.get("/auth/me", response_model=UserPublic)
async def me(user: dict = Depends(get_current_user)):
    return UserPublic(id=user["id"], email=user["email"], name=user["name"], role=user["role"])


# ---------- Services routes ----------
@api_router.get("/services")
async def list_services():
    return SERVICES


# ---------- Availability (public) ----------
@api_router.get("/availability")
async def public_availability(date: str):
    """Return the default hours minus any that are already booked (pending/confirmed) for the given date."""
    if not date or len(date) != 10:
        raise HTTPException(status_code=400, detail="Data non valida")
    taken_docs = await db.bookings.find(
        {"preferred_date": date, "status": {"$in": ["pending", "confirmed"]}},
        {"_id": 0, "preferred_time": 1},
    ).to_list(200)
    taken = {d["preferred_time"] for d in taken_docs}
    free = [t for t in DEFAULT_HOURS if t not in taken]
    return {"date": date, "times": free}


# ---------- Bookings routes ----------
@api_router.post("/bookings", response_model=Booking)
async def create_booking(payload: BookingCreate):
    if payload.service_id not in SERVICE_MAP:
        raise HTTPException(status_code=400, detail="Servizio non valido")

    if await _is_time_taken(payload.date, payload.time):
        raise HTTPException(status_code=409, detail="Orario non più disponibile, scegline un altro")

    booking_id = str(uuid.uuid4())
    booking = {
        "id": booking_id,
        "first_name": payload.first_name.strip(),
        "last_name": payload.last_name.strip(),
        "phone": payload.phone.strip(),
        "dog_name": payload.dog_name.strip(),
        "dog_breed": payload.dog_breed.strip(),
        "dog_size": payload.dog_size,
        "service_id": payload.service_id,
        "service_name": SERVICE_MAP[payload.service_id]["name"],
        "preferred_date": payload.date,
        "preferred_time": payload.time,
        "time_preference": payload.time_preference.strip(),
        "notes": payload.notes.strip(),
        "status": "pending",
        "source": "online",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "confirmed_at": None,
        "verified_by": None,
        "staff_note": None,
    }
    await db.bookings.insert_one(booking)
    booking.pop("_id", None)
    return Booking(**booking)


@api_router.post("/bookings/manual", response_model=Booking)
async def create_manual_booking(payload: ManualBookingCreate, user: dict = Depends(get_current_user)):
    if payload.service_id not in SERVICE_MAP:
        raise HTTPException(status_code=400, detail="Servizio non valido")

    if await _is_time_taken(payload.date, payload.time):
        raise HTTPException(status_code=409, detail="Orario già prenotato da un altro cliente")

    now = datetime.now(timezone.utc).isoformat()
    booking_id = str(uuid.uuid4())
    booking = {
        "id": booking_id,
        "first_name": payload.first_name.strip(),
        "last_name": payload.last_name.strip(),
        "phone": payload.phone.strip(),
        "dog_name": (payload.dog_name or "").strip() or None,
        "dog_breed": (payload.dog_breed or "").strip() or None,
        "dog_size": payload.dog_size,
        "service_id": payload.service_id,
        "service_name": SERVICE_MAP[payload.service_id]["name"],
        "preferred_date": payload.date,
        "preferred_time": payload.time,
        "time_preference": None,
        "notes": (payload.notes or "").strip() or None,
        "status": "confirmed",
        "source": "manual",
        "created_at": now,
        "confirmed_at": now,
        "verified_by": user["name"],
        "staff_note": "Prenotazione registrata manualmente dallo staff",
    }
    await db.bookings.insert_one(booking)
    booking.pop("_id", None)
    return Booking(**booking)


@api_router.get("/bookings", response_model=List[Booking])
async def list_bookings(status: Optional[str] = None, user: dict = Depends(get_current_user)):
    query = {}
    if status and status != "all":
        query["status"] = status
    docs = await db.bookings.find(query, {"_id": 0}).sort("created_at", -1).to_list(500)
    return [Booking(**d) for d in docs]


@api_router.get("/bookings/stats")
async def booking_stats(user: dict = Depends(get_current_user)):
    pending = await db.bookings.count_documents({"status": "pending"})
    confirmed = await db.bookings.count_documents({"status": "confirmed"})
    rejected = await db.bookings.count_documents({"status": "rejected"})
    total = await db.bookings.count_documents({})
    return {"pending": pending, "confirmed": confirmed, "rejected": rejected, "total": total}


@api_router.post("/bookings/{booking_id}/confirm", response_model=Booking)
async def confirm_booking(booking_id: str, payload: StatusUpdate, user: dict = Depends(get_current_user)):
    result = await db.bookings.find_one_and_update(
        {"id": booking_id},
        {"$set": {
            "status": "confirmed",
            "confirmed_at": datetime.now(timezone.utc).isoformat(),
            "verified_by": user["name"],
            "staff_note": payload.staff_note,
        }},
        return_document=True,
    )
    if not result:
        raise HTTPException(status_code=404, detail="Prenotazione non trovata")
    result.pop("_id", None)
    return Booking(**result)


@api_router.post("/bookings/{booking_id}/reject", response_model=Booking)
async def reject_booking(booking_id: str, payload: StatusUpdate, user: dict = Depends(get_current_user)):
    result = await db.bookings.find_one_and_update(
        {"id": booking_id},
        {"$set": {
            "status": "rejected",
            "confirmed_at": datetime.now(timezone.utc).isoformat(),
            "verified_by": user["name"],
            "staff_note": payload.staff_note,
        }},
        return_document=True,
    )
    if not result:
        raise HTTPException(status_code=404, detail="Prenotazione non trovata")
    result.pop("_id", None)
    return Booking(**result)


@api_router.delete("/bookings/{booking_id}")
async def delete_booking(booking_id: str, user: dict = Depends(get_current_user)):
    result = await db.bookings.delete_one({"id": booking_id})
    if not result.deleted_count:
        raise HTTPException(status_code=404, detail="Prenotazione non trovata")
    return {"success": True}


@api_router.get("/")
async def root():
    return {"status": "ok", "service": "Roberta's Beauty Dog Center API"}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL, "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Startup ----------
@app.on_event("startup")
async def on_startup():
    await db.users.create_index("email", unique=True)
    await db.bookings.create_index("status")
    await db.bookings.create_index("created_at")
    await db.bookings.create_index([("preferred_date", 1), ("preferred_time", 1)])
    # Drop legacy slots collection if it exists
    try:
        await db.slots.drop()
    except Exception:
        pass

    admin_email = os.environ.get("ADMIN_EMAIL", "admin@example.com").lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "admin123")
    admin_name = os.environ.get("ADMIN_NAME", "Roberta")

    existing = await db.users.find_one({"email": admin_email})
    if existing is None:
        await db.users.insert_one({
            "id": str(uuid.uuid4()),
            "email": admin_email,
            "password_hash": hash_password(admin_password),
            "name": admin_name,
            "role": "staff",
            "token_version": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("Seeded admin user %s", admin_email)
    elif not verify_password(admin_password, existing["password_hash"]):
        await db.users.update_one(
            {"email": admin_email},
            {"$set": {"password_hash": hash_password(admin_password), "name": admin_name}},
        )
        logger.info("Updated admin password for %s", admin_email)


@app.on_event("shutdown")
async def on_shutdown():
    client.close()
