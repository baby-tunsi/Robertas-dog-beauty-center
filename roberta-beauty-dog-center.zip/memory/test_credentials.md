# Test Credentials — Roberta's Beauty Dog Center

## Staff Access
- **Login page**: `/staff/login`
- **Access code**: `17052` (single 5-digit code, no email/password)
- **Dashboard**: `/staff/dashboard`

## Auth Endpoints
- `POST /api/auth/code-login` — body `{code: "17052"}` — sets httpOnly cookie
- `POST /api/auth/logout`
- `GET /api/auth/me`

## Booking Endpoints
- `POST /api/bookings` — public creation
- `GET /api/bookings?status=pending|confirmed|rejected|all` — staff
- `GET /api/bookings/stats` — staff
- `POST /api/bookings/{id}/confirm` — staff (body `{staff_note?}`)
- `POST /api/bookings/{id}/reject` — staff
- `DELETE /api/bookings/{id}` — staff

## Public
- `GET /api/services` — list of grooming services
