# PRD — Roberta's Beauty Dog Center

## Original problem statement
"Creami un sito di una toilettatura con opsioni che mostrano che servisi offriamo e con possibila di accendere con account staff per ricevere le prenotazioni e conferamrle verificando il numero nome e cognome"

Business context (from Google Maps): Roberta's Beauty Dog Center — Corso Europa 22, 17020 Borghetto Santo Spirito (SV), Italy — +39 338 292 9207 — 4.8★ rating.

## Architecture
- **Backend**: FastAPI + MongoDB (motor). JWT auth via httpOnly cookie (bcrypt hashed pw). Startup seeds owner account.
- **Frontend**: React 19 + Tailwind + Fraunces/Manrope fonts + sonner toasts + lucide-react icons.
- **Palette**: cream #FDFBF7, sand #F4EFE6, terracotta #C86D51, sage #6E8B74, espresso #2B231F.

## Personas
- **Cliente**: proprietario di cane in zona Borghetto, cerca info servizi e prenota online (senza account).
- **Roberta (staff/owner)**: accede all'area riservata, vede richieste, verifica dati e conferma.

## Requirements (static)
- Public homepage in Italian: hero, services grid, chi siamo, booking form, contatti + mappa
- Public booking (nome, cognome, telefono, dati cane, servizio, data/ora, note) → status `pending`
- Staff login (email/password) with JWT cookie
- Staff dashboard: filtri per stato (pending/confirmed/rejected/all), stats, verifica cliente (nome/cognome/telefono in evidenza), azioni Conferma/Rifiuta con nota interna, elimina

## Implemented (2026-02)
- Backend endpoints: /api/auth/{login,logout,me}, /api/services, /api/bookings CRUD + /confirm + /reject + /stats
- Frontend: HomePage con Header + Hero + Services + About + BookingForm + Contact + Footer
- Staff pages: StaffLogin, StaffDashboard con verification panel e filtri
- Admin seeded: medkhaskhoussi@gmail.com / Roberta2026!
- Google Maps embed of the salon location
- Fully responsive, mobile menu, sonner toasts, data-testid attributes on all interactive elements

## Backlog (P1/P2)
- P1: Email notifica automatica al cliente quando prenotazione confermata (Resend playbook)
- P1: SMS di conferma via Twilio
- P2: Calendario visuale disponibilità staff
- P2: Gestione multi-staff con permessi
- P2: Gallery foto "prima/dopo" dei cani
- P2: Recensioni clienti sulla homepage
