import { PawPrint } from "lucide-react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-[var(--espresso)] text-[var(--cream)]/80 py-14">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 flex flex-col md:flex-row justify-between gap-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[var(--terracotta)] flex items-center justify-center text-[var(--cream)]">
            <PawPrint size={20} />
          </div>
          <div>
            <div className="font-serif-display text-lg text-[var(--cream)]">Roberta's Beauty Dog Center</div>
            <div className="text-xs">Toilettatura professionale · Borghetto Santo Spirito</div>
          </div>
        </div>
        <div className="text-sm space-y-2">
          <p>Corso Europa, 22 · 17020 Borghetto Santo Spirito (SV)</p>
          <p>+39 338 292 9207</p>
          <Link to="/staff/login" className="link-underline text-[var(--cream)]/70 hover:text-[var(--cream)]">
            Area Staff →
          </Link>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-5 sm:px-8 mt-8 pt-6 border-t border-white/10 text-xs">
        © {new Date().getFullYear()} Roberta's Beauty Dog Center. Tutti i diritti riservati.
      </div>
    </footer>
  );
}
