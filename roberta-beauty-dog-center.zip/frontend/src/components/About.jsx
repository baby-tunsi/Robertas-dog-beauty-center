export default function About() {
  return (
    <section id="chi-siamo" className="py-24 md:py-32 bg-[var(--cream)]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid md:grid-cols-2 gap-12 md:gap-20 items-center">
        <div className="relative">
          <div className="aspect-square rounded-[2rem] overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1552053831-71594a27632d?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxOTF8MHwxfHNlYXJjaHwyfHxoYXBweSUyMGRvZ3xlbnwwfHx8fDE3ODg1NjYyNjZ8MA&ixlib=rb-4.1.0&q=85"
              alt="Golden retriever felice"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="hidden md:block absolute -bottom-10 -right-10 w-48 h-48 rounded-[1.5rem] overflow-hidden border-8 border-[var(--cream)] shadow-xl">
            <img
              src="https://images.unsplash.com/photo-1534361960057-19889db9621e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxOTF8MHwxfHNlYXJjaHw0fHxoYXBweSUyMGRvZ3xlbnwwfHx8fDE3ODg1NjYyNjZ8MA&ixlib=rb-4.1.0&q=85"
              alt="Cane che gioca"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div data-testid="about-story-container">
          <div className="eyebrow">Chi Siamo</div>
          <h2 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-[var(--espresso)] mt-4 leading-tight">
            La cura di Roberta,<br />
            la <span className="italic text-[var(--terracotta)]">firma di un salone</span> boutique.
          </h2>
          <div className="mt-6 space-y-4 text-[var(--warm-grey)] leading-relaxed">
            <p>
              Aperto nel cuore di Borghetto Santo Spirito, il nostro centro nasce dalla passione
              di Roberta per gli animali e dalla convinzione che ogni cane meriti un momento
              tutto suo, senza fretta.
            </p>
            <p>
              Lavoriamo con appuntamenti scaglionati per garantire tempo e attenzione a ciascuno.
              I nostri prodotti sono selezionati con cura, biodegradabili e adatti anche alle pelli
              più sensibili.
            </p>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-4">
            {[
              { n: "10+", l: "Anni di esperienza" },
              { n: "1500+", l: "Cani coccolati" },
              { n: "4.8★", l: "Rating Google" },
            ].map((s) => (
              <div key={s.l} className="border-l-2 border-[var(--terracotta)] pl-4">
                <div className="font-serif-display text-3xl font-semibold text-[var(--espresso)]">{s.n}</div>
                <div className="text-xs text-[var(--warm-grey)] mt-1 leading-tight">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
