import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Bath, Scissors, Sparkles, Ear, Heart, Clock } from "lucide-react";

const ICONS = {
  bagno: Bath,
  taglio: Scissors,
  unghie: Heart,
  orecchie: Ear,
  spa: Sparkles,
};

export default function Services({ onSelectService }) {
  const [services, setServices] = useState([]);

  useEffect(() => {
    api.get("/services").then((r) => setServices(r.data)).catch(() => {});
  }, []);

  return (
    <section id="servizi" className="relative py-24 md:py-32 bg-[var(--sand)]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="max-w-2xl">
          <div className="eyebrow">I Nostri Servizi</div>
          <h2 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-[var(--espresso)] mt-4 leading-tight">
            Trattamenti pensati per il tuo <span className="italic text-[var(--terracotta)]">migliore amico</span>.
          </h2>
          <p className="mt-5 text-[var(--warm-grey)] leading-relaxed">
            Ogni servizio è personalizzato in base a razza, taglia e temperamento del cane.
            Utilizziamo solo prodotti dermatologicamente testati.
          </p>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => {
            const Icon = ICONS[s.id] || Sparkles;
            return (
              <div
                key={s.id}
                data-testid={`service-card-${s.id}`}
                className="card-tactile p-7 flex flex-col relative overflow-hidden"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="w-12 h-12 rounded-2xl bg-[var(--sage-soft)] flex items-center justify-center text-[var(--sage)] mb-5">
                  <Icon size={22} />
                </div>
                <h3 className="font-serif-display text-2xl text-[var(--espresso)] font-semibold">
                  {s.name}
                </h3>
                <p className="mt-3 text-sm text-[var(--warm-grey)] leading-relaxed flex-1">
                  {s.description}
                </p>
                <div className="mt-6 flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-[var(--warm-grey)]">
                    <Clock size={14} />
                    <span>{s.duration}</span>
                  </div>
                  <div className="font-serif-display text-lg font-semibold text-[var(--terracotta)]">
                    €{s.price_min}–{s.price_max}
                  </div>
                </div>
                <button
                  onClick={() => onSelectService?.(s.id)}
                  data-testid={`service-book-${s.id}`}
                  className="mt-6 text-sm font-semibold text-[var(--espresso)] self-start link-underline"
                >
                  Prenota questo servizio →
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
