import { MapPin, Phone, Clock } from "lucide-react";

const HOURS = [
  ["Lunedì", "9:00 — 18:00"],
  ["Martedì", "9:00 — 18:00"],
  ["Mercoledì", "9:00 — 18:00"],
  ["Giovedì", "9:00 — 18:00"],
  ["Venerdì", "9:00 — 18:00"],
  ["Sabato", "9:00 — 13:00"],
  ["Domenica", "Chiuso"],
];

export default function Contact() {
  return (
    <section id="contatti" className="py-24 md:py-32 bg-[var(--sand)]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid md:grid-cols-2 gap-12 md:gap-16">
        <div>
          <div className="eyebrow">Contatti</div>
          <h2 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-[var(--espresso)] mt-4 leading-tight">
            Passa a trovarci o <span className="italic text-[var(--terracotta)]">chiama</span>.
          </h2>

          <div className="mt-10 space-y-8">
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[var(--cream)] flex items-center justify-center text-[var(--terracotta)] shrink-0">
                <MapPin size={20} />
              </div>
              <div>
                <div className="eyebrow">Indirizzo</div>
                <p data-testid="contact-address" className="mt-1 text-[var(--espresso)] font-medium">
                  Corso Europa, 22<br />17020 Borghetto Santo Spirito (SV)
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[var(--cream)] flex items-center justify-center text-[var(--terracotta)] shrink-0">
                <Phone size={20} />
              </div>
              <div>
                <div className="eyebrow">Telefono</div>
                <a
                  data-testid="contact-phone-link"
                  href="tel:+393382929207"
                  className="mt-1 block text-[var(--espresso)] font-medium hover:text-[var(--terracotta)]"
                >
                  +39 338 292 9207
                </a>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[var(--cream)] flex items-center justify-center text-[var(--terracotta)] shrink-0">
                <Clock size={20} />
              </div>
              <div className="flex-1">
                <div className="eyebrow">Orari di apertura</div>
                <table data-testid="opening-hours-table" className="mt-2 w-full max-w-sm text-sm">
                  <tbody>
                    {HOURS.map(([d, h]) => (
                      <tr key={d} className="border-b border-[rgba(43,35,31,0.08)]">
                        <td className="py-2 text-[var(--warm-grey)]">{d}</td>
                        <td className="py-2 text-right font-medium text-[var(--espresso)]">{h}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div
          data-testid="map-container"
          className="rounded-[2rem] overflow-hidden shadow-[0_25px_60px_-30px_rgba(43,35,31,0.35)] min-h-[420px]"
        >
          <iframe
            title="Roberta's Beauty Dog Center - Mappa"
            src="https://www.google.com/maps?q=Corso+Europa,+22,+17020+Borghetto+Santo+Spirito+SV&output=embed"
            className="w-full h-full min-h-[420px] border-0"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}
