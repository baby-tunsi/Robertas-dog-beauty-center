import { Link, useLocation } from "react-router-dom";
import { PawPrint, Menu, X } from "lucide-react";
import { useState } from "react";

const links = [
  { href: "#servizi", label: "Servizi" },
  { href: "#chi-siamo", label: "Chi Siamo" },
  { href: "#contatti", label: "Contatti" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const onHome = pathname === "/";

  return (
    <header className="glass-nav sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-20 flex items-center justify-between">
        <Link to="/" data-testid="nav-home-link" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-[var(--terracotta)] flex items-center justify-center text-[var(--cream)] transition-transform group-hover:rotate-12">
            <PawPrint size={20} />
          </div>
          <div className="leading-tight">
            <div className="font-serif-display text-lg font-semibold text-[var(--espresso)]">Roberta's</div>
            <div className="eyebrow -mt-0.5">Beauty Dog Center</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {onHome && links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              data-testid={`nav-${l.label.toLowerCase().replace(/ /g, "-")}-link`}
              className="link-underline text-sm font-medium text-[var(--warm-grey)] hover:text-[var(--espresso)]"
            >
              {l.label}
            </a>
          ))}
          {onHome && (
            <a href="#prenota" data-testid="nav-book-button" className="btn-primary text-sm">
              Prenota
            </a>
          )}
          <Link
            to="/staff/login"
            data-testid="nav-staff-login-button"
            className="btn-ghost text-sm"
          >
            Area Staff
          </Link>
        </nav>

        <button
          data-testid="nav-mobile-toggle"
          className="md:hidden p-2"
          onClick={() => setOpen(!open)}
          aria-label="Menu"
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-[rgba(43,35,31,0.08)] bg-[var(--cream)]">
          <div className="flex flex-col px-5 py-4 gap-3">
            {onHome && links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="py-2 text-[var(--espresso)] font-medium"
              >
                {l.label}
              </a>
            ))}
            {onHome && (
              <a href="#prenota" onClick={() => setOpen(false)} className="btn-primary justify-center">
                Prenota
              </a>
            )}
            <Link to="/staff/login" onClick={() => setOpen(false)} className="btn-ghost justify-center">
              Area Staff
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
