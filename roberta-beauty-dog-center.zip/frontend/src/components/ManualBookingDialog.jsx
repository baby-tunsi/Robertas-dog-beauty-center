import { useEffect, useState } from "react";
import { api, formatApiErrorDetail } from "@/lib/api";
import { toast } from "sonner";
import { X, UserPlus, Loader2 } from "lucide-react";

export default function ManualBookingDialog({ open, onClose, onCreated }) {
  const [services, setServices] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    first_name: "", last_name: "", phone: "",
    dog_name: "", dog_breed: "", dog_size: "media",
    service_id: "bagno", date: "", time: "", notes: "",
  });

  useEffect(() => {
    if (open) api.get("/services").then((r) => setServices(r.data)).catch(() => {});
  }, [open]);

  useEffect(() => {
    if (!open) {
      setForm({
        first_name: "", last_name: "", phone: "",
        dog_name: "", dog_breed: "", dog_size: "media",
        service_id: "bagno", date: "", time: "", notes: "",
      });
    }
  }, [open]);

  if (!open) return null;

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.first_name || !form.last_name || !form.phone || !form.date || !form.time) {
      toast.error("Compila tutti i campi obbligatori");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/bookings/manual", form);
      toast.success("Prenotazione manuale registrata");
      onCreated?.();
      onClose();
    } catch (err) {
      toast.error(formatApiErrorDetail(err.response?.data?.detail) || "Errore");
    } finally {
      setSubmitting(false);
    }
  };

  const inputCls =
    "w-full bg-[var(--cream)] border border-[rgba(43,35,31,0.12)] rounded-xl px-4 py-2.5 text-[var(--espresso)] placeholder:text-[var(--warm-grey)]/60 focus:outline-none focus:border-[var(--terracotta)] focus:ring-2 focus:ring-[var(--terracotta)]/15 transition";

  const today = new Date().toISOString().split("T")[0];

  return (
    <div
      data-testid="manual-booking-dialog"
      className="fixed inset-0 z-50 flex items-center justify-center px-4 py-8"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-[var(--espresso)]/60 backdrop-blur-sm" />
      <div
        className="relative bg-white rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b border-[rgba(43,35,31,0.08)] px-6 md:px-8 py-5 flex items-center justify-between rounded-t-3xl">
          <div>
            <div className="eyebrow flex items-center gap-2"><UserPlus size={14} /> Prenotazione manuale</div>
            <h3 className="font-serif-display text-2xl text-[var(--espresso)] mt-1">
              Registra un cliente al telefono
            </h3>
          </div>
          <button
            onClick={onClose}
            data-testid="manual-booking-close"
            className="w-9 h-9 rounded-full hover:bg-[var(--sand)] flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={submit} className="px-6 md:px-8 py-6 space-y-4" data-testid="manual-booking-form">
          <p className="text-sm text-[var(--warm-grey)]">
            L'orario verrà bloccato automaticamente così nessun altro cliente potrà prenotare la stessa fascia.
          </p>

          <div className="grid sm:grid-cols-2 gap-3">
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Nome *</span>
              <input data-testid="manual-first-name" className={`${inputCls} mt-1.5`} value={form.first_name} onChange={(e) => update("first_name", e.target.value)} required />
            </label>
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Cognome *</span>
              <input data-testid="manual-last-name" className={`${inputCls} mt-1.5`} value={form.last_name} onChange={(e) => update("last_name", e.target.value)} required />
            </label>
          </div>
          <label className="block">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Telefono *</span>
            <input data-testid="manual-phone" type="tel" className={`${inputCls} mt-1.5`} value={form.phone} onChange={(e) => update("phone", e.target.value)} required />
          </label>
          <div className="grid sm:grid-cols-2 gap-3">
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Nome cane</span>
              <input data-testid="manual-dog-name" className={`${inputCls} mt-1.5`} value={form.dog_name} onChange={(e) => update("dog_name", e.target.value)} />
            </label>
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Razza</span>
              <input data-testid="manual-dog-breed" className={`${inputCls} mt-1.5`} value={form.dog_breed} onChange={(e) => update("dog_breed", e.target.value)} />
            </label>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Taglia</span>
              <select data-testid="manual-dog-size" className={`${inputCls} mt-1.5`} value={form.dog_size} onChange={(e) => update("dog_size", e.target.value)}>
                <option value="piccola">Piccola</option>
                <option value="media">Media</option>
                <option value="grande">Grande</option>
                <option value="gigante">Gigante</option>
              </select>
            </label>
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Servizio *</span>
              <select data-testid="manual-service" className={`${inputCls} mt-1.5`} value={form.service_id} onChange={(e) => update("service_id", e.target.value)} required>
                {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </label>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Data *</span>
              <input data-testid="manual-date" type="date" min={today} className={`${inputCls} mt-1.5`} value={form.date} onChange={(e) => update("date", e.target.value)} required />
            </label>
            <label>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Orario *</span>
              <input data-testid="manual-time" type="time" className={`${inputCls} mt-1.5`} value={form.time} onChange={(e) => update("time", e.target.value)} required />
            </label>
          </div>
          <label className="block">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Note</span>
            <textarea data-testid="manual-notes" className={`${inputCls} mt-1.5 min-h-[70px]`} value={form.notes} onChange={(e) => update("notes", e.target.value)} />
          </label>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="btn-ghost"
            >
              Annulla
            </button>
            <button
              type="submit"
              data-testid="manual-booking-submit"
              disabled={submitting}
              className="btn-primary disabled:opacity-50"
            >
              {submitting ? <Loader2 size={16} className="animate-spin" /> : <UserPlus size={16} />}
              Registra e blocca orario
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
