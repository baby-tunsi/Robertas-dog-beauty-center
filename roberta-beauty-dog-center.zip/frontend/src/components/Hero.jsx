import { Phone, Star, MapPin } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 grain" />
      <div className="max-w-7xl mx-auto px-5 sm:px-8 pt-16 pb-24 md:pt-24 md:pb-32 grid md:grid-cols-2 gap-12 md:gap-16 items-center">
        <div className="relative z-10">
          <div className="eyebrow animate-fade-up delay-1" data-testid="hero-eyebrow">
            Toilettatura Professionale · Borghetto Santo Spirito
          </div>
          <h1
            data-testid="hero-title"
            className="font-serif-display text-4xl sm:text-5xl lg:text-6xl font-semibold text-[var(--espresso)] leading-[1.05] tracking-tight mt-4 animate-fade-up delay-2"
          >
            Il benessere del tuo cane,
            <span className="italic text-[var(--terracotta)]"> nel cuore della Liguria.</span>
          </h1>
          <p className="mt-6 text-base md:text-lg text-[var(--warm-grey)] max-w-lg leading-relaxed animate-fade-up delay-3">
            Da oltre dieci anni Roberta e il suo team si prendono cura di ogni cane con tecniche
            delicate, prodotti selezionati e tanta pazienza. Bagno, taglio, spa e coccole in un
            ambiente rilassato.
          </p>

          <div className="mt-8 flex flex-wrap gap-3 animate-fade-up delay-4">
            <a href="#prenota" data-testid="hero-book-cta" className="btn-primary">
              Prenota una visita
            </a>
            <a href="tel:+393382929207" data-testid="hero-phone-cta" className="btn-ghost">
              <Phone size={16} /> +39 338 292 9207
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-6 text-sm text-[var(--warm-grey)]">
            <div className="flex items-center gap-2">
              <div className="flex text-[#DAA520]">
                {["s1", "s2", "s3", "s4", "s5"].map((k) => (
                  <Star key={k} size={16} fill="#DAA520" strokeWidth={0} />
                ))}
              </div>
              <span className="font-semibold text-[var(--espresso)]">4.8</span>
              <span>· Recensioni Google</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={16} />
              <span>Corso Europa, 22</span>
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="relative aspect-[4/5] rounded-[2rem] overflow-hidden shadow-[0_30px_60px_-30px_rgba(43,35,31,0.35)]">
            <img
              src="https://images.pexels.com/photos/19145894/pexels-photo-19145894.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt="Toelettatura di un cane"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="hidden md:block absolute -bottom-8 -left-8 w-40 h-40 rounded-[1.5rem] overflow-hidden border-8 border-[var(--cream)] shadow-xl">
            <img
              src="https://images.pexels.com/photos/21952862/pexels-photo-21952862.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=350&w=350"
              alt="Cocker groomato"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -top-6 -right-4 bg-[var(--sage-soft)] rounded-2xl px-4 py-3 shadow-md">
            <div className="eyebrow">Aperto oggi</div>
            <div className="font-serif-display text-lg text-[var(--espresso)]">9:00 — 18:00</div>
          </div>
        </div>
      </div>
    </section>
  );
}
