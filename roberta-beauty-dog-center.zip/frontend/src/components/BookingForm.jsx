import { useEffect, useState } from "react";
import { api, formatApiErrorDetail } from "@/lib/api";
import { toast } from "sonner";
import { CheckCircle2, Send, Calendar, Clock } from "lucide-react";

function formatDateLabel(iso) {
  try {
    const [y, m, d] = iso.split("-");
    const dt = new Date(+y, +m - 1, +d);
    return dt.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long" });
  } catch { return iso; }
}

export default function BookingForm({ initialService }) {
  const [services, setServices] = useState([]);
  const [availableTimes, setAvailableTimes] = useState([]);
  const [loadingTimes, setLoadingTimes] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    first_name: "", last_name: "", phone: "",
    dog_name: "", dog_breed: "", dog_size: "media",
    service_id: initialService || "bagno",
    date: "", time: "",
    time_preference: "",
    notes: "",
  });

  useEffect(() => {
    api.get("/services").then((r) => setServices(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    if (initialService) setForm((f) => ({ ...f, service_id: initialService }));
  }, [initialService]);

  useEffect(() => {
    if (!form.date) {
      setAvailableTimes([]);
      return;
    }
    setLoadingTimes(true);
    api
      .get(`/availability?date=${form.date}`)
      .then((r) => setAvailableTimes(r.data.times || []))
      .catch(() => setAvailableTimes([]))
      .finally(() => setLoadingTimes(false));
  }, [form.date]);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v, ...(k === "date" ? { time: "" } : {}) }));

  const submit = async (e) => {
    e.preventDefault();
    const missing = [];
    if (!form.first_name.trim()) missing.push("nome");
    if (!form.last_name.trim()) missing.push("cognome");
    if (!form.phone.trim()) missing.push("telefono");
    if (!form.dog_name.trim()) missing.push("nome del cane");
    if (!form.dog_breed.trim()) missing.push("razza");
    if (!form.date) missing.push("data");
    if (!form.time) missing.push("orario");
    if (!form.time_preference.trim()) missing.push("preferenza orario");
    if (!form.notes.trim()) missing.push("note particolari");
    if (missing.length) {
      toast.error(`Compila: ${missing.join(", ")}`);
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/bookings", form);
      setSubmitted(true);
      toast.success("Prenotazione inviata! Ti chiameremo per confermare.");
      setForm({
        first_name: "", last_name: "", phone: "", dog_name: "", dog_breed: "",
        dog_size: "media", service_id: form.service_id, date: "", time: "",
        time_preference: "", notes: "",
      });
    } catch (err) {
      const msg = formatApiErrorDetail(err.response?.data?.detail) || "Errore invio";
      toast.error(msg);
      if (err.response?.status === 409 && form.date) {
        // refresh times so user sees the current availability
        try {
          const r = await api.get(`/availability?date=${form.date}`);
          setAvailableTimes(r.data.times || []);
        } catch (refreshErr) {
          console.warn("Failed to refresh availability after 409", refreshErr);
        }
      }
    } finally {
      setSubmitting(false);
    }
  };

  const inputCls =
    "w-full bg-[var(--cream)] border border-[rgba(43,35,31,0.12)] rounded-xl px-4 py-3 text-[var(--espresso)] placeholder:text-[var(--warm-grey)]/60 focus:outline-none focus:border-[var(--terracotta)] focus:ring-2 focus:ring-[var(--terracotta)]/15 transition";

  const today = new Date().toISOString().split("T")[0];

  return (
    <section id="prenota" className="py-24 md:py-32 bg-[var(--espresso)] relative overflow-hidden">
      <div className="absolute inset-0 grain opacity-40" />
      <div className="max-w-6xl mx-auto px-5 sm:px-8 grid md:grid-cols-5 gap-12 relative">
        <div className="md:col-span-2 text-[var(--cream)]">
          <div className="eyebrow" style={{ color: "#DAA520" }}>Prenota Online</div>
          <h2 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-semibold mt-4 leading-tight">
            Un appuntamento su <span className="italic text-[var(--terracotta)]">misura</span> per il tuo cane.
          </h2>
          <p className="mt-5 text-[var(--cream)]/75 leading-relaxed">
            Scegli il giorno e l'orario preferiti — vedrai solo le fasce ancora libere.
            Ti chiameremo per confermare la prenotazione.
          </p>
          <div className="mt-8 space-y-3 text-sm text-[var(--cream)]/80">
            <p>· Nessun pagamento richiesto adesso</p>
            <p>· Conferma via telefono con verifica dei tuoi dati</p>
            <p>· Cancellazione gratuita fino a 24h prima</p>
          </div>
        </div>

        <div className="md:col-span-3">
          {submitted ? (
            <div data-testid="booking-success" className="bg-[var(--cream)] rounded-3xl p-10 text-center">
              <CheckCircle2 className="mx-auto text-[var(--sage)]" size={56} />
              <h3 className="font-serif-display text-3xl mt-6 text-[var(--espresso)]">Prenotazione inviata!</h3>
              <p className="mt-4 text-[var(--warm-grey)]">
                Grazie, ti chiameremo al numero fornito per confermare l'appuntamento.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                data-testid="booking-new"
                className="btn-ghost mt-8"
              >
                Nuova prenotazione
              </button>
            </div>
          ) : (
            <form
              data-testid="booking-form"
              onSubmit={submit}
              className="bg-[var(--cream)] rounded-3xl p-6 md:p-8 space-y-5"
            >
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Nome *</span>
                  <input data-testid="booking-first-name-input" className={`${inputCls} mt-2`} value={form.first_name} onChange={(e) => update("first_name", e.target.value)} required />
                </label>
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Cognome *</span>
                  <input data-testid="booking-last-name-input" className={`${inputCls} mt-2`} value={form.last_name} onChange={(e) => update("last_name", e.target.value)} required />
                </label>
              </div>
              <label className="block">
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Telefono *</span>
                <input data-testid="booking-phone-input" className={`${inputCls} mt-2`} type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="+39 ..." required />
              </label>
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Nome del cane *</span>
                  <input data-testid="booking-dog-name-input" className={`${inputCls} mt-2`} value={form.dog_name} onChange={(e) => update("dog_name", e.target.value)} required />
                </label>
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Razza *</span>
                  <input data-testid="booking-dog-breed-input" className={`${inputCls} mt-2`} value={form.dog_breed} onChange={(e) => update("dog_breed", e.target.value)} placeholder="es. Barboncino, Cocker…" required />
                </label>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Taglia</span>
                  <select data-testid="booking-dog-size-select" className={`${inputCls} mt-2`} value={form.dog_size} onChange={(e) => update("dog_size", e.target.value)}>
                    <option value="piccola">Piccola</option>
                    <option value="media">Media</option>
                    <option value="grande">Grande</option>
                    <option value="gigante">Gigante</option>
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Servizio *</span>
                  <select data-testid="booking-service-select" className={`${inputCls} mt-2`} value={form.service_id} onChange={(e) => update("service_id", e.target.value)} required>
                    {services.map((s) => (<option key={s.id} value={s.id}>{s.name}</option>))}
                  </select>
                </label>
              </div>

              {/* Date + times */}
              <div className="rounded-2xl bg-white border border-[rgba(43,35,31,0.08)] p-5">
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)] flex items-center gap-1.5">
                    <Calendar size={13} /> Scegli la data *
                  </span>
                  <input
                    data-testid="booking-date-input"
                    type="date"
                    min={today}
                    value={form.date}
                    onChange={(e) => update("date", e.target.value)}
                    className={`${inputCls} mt-2`}
                    required
                  />
                </label>

                {form.date && (
                  <div className="mt-5">
                    <div className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)] flex items-center gap-1.5">
                      <Clock size={13} /> Orari disponibili — {formatDateLabel(form.date)}
                    </div>
                    {loadingTimes ? (
                      <div className="mt-3 text-sm text-[var(--warm-grey)]">Caricamento…</div>
                    ) : availableTimes.length === 0 ? (
                      <div data-testid="booking-no-times" className="mt-3 text-sm text-[var(--warm-grey)]">
                        Nessun orario disponibile in questa giornata. Prova un altro giorno o chiamaci.
                      </div>
                    ) : (
                      <div className="mt-3 flex flex-wrap gap-2" data-testid="booking-time-picker">
                        {availableTimes.map((t) => (
                          <button
                            type="button"
                            key={t}
                            onClick={() => update("time", t)}
                            data-testid={`booking-time-${t}`}
                            className={`px-4 py-2 rounded-xl text-sm font-semibold border transition inline-flex items-center gap-1.5 ${
                              form.time === t
                                ? "bg-[var(--terracotta)] text-[var(--cream)] border-[var(--terracotta)]"
                                : "bg-white text-[var(--espresso)] border-[rgba(43,35,31,0.12)] hover:border-[var(--terracotta)]"
                            }`}
                          >
                            <Clock size={13} /> {t}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <label className="block">
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">
                  Preferenza sull'orario *
                </span>
                <input
                  data-testid="booking-time-preference-input"
                  className={`${inputCls} mt-2`}
                  value={form.time_preference}
                  onChange={(e) => update("time_preference", e.target.value)}
                  placeholder="es. preferirei un po' prima, se possibile…"
                  required
                />
              </label>

              <label className="block">
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)]">Note particolari *</span>
                <textarea
                  data-testid="booking-notes-input"
                  className={`${inputCls} mt-2 min-h-[80px]`}
                  value={form.notes}
                  onChange={(e) => update("notes", e.target.value)}
                  placeholder="Allergie, comportamento, preferenze di taglio…"
                  required
                />
              </label>

              <button
                type="submit"
                data-testid="booking-submit-button"
                disabled={submitting}
                className="btn-primary w-full justify-center disabled:opacity-50"
              >
                <Send size={16} /> {submitting ? "Invio in corso…" : "Invia richiesta di prenotazione"}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
