import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { api, formatApiErrorDetail } from "@/lib/api";
import { PawPrint, ArrowLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";

const CODE_LENGTH = 5;
const CODE_SLOT_IDS = Array.from({ length: CODE_LENGTH }, (_, i) => `slot-${i}`);

export default function StaffLogin() {
  const { user, refresh } = useAuth();
  const navigate = useNavigate();
  const [digits, setDigits] = useState(Array(CODE_LENGTH).fill(""));
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const inputsRef = useRef([]);

  useEffect(() => {
    if (user) navigate("/staff/dashboard", { replace: true });
  }, [user, navigate]);

  useEffect(() => {
    inputsRef.current[0]?.focus();
  }, []);

  const submitCode = async (code) => {
    setError("");
    setSubmitting(true);
    try {
      await api.post("/auth/code-login", { code });
      await refresh();
      toast.success("Accesso effettuato");
      navigate("/staff/dashboard", { replace: true });
    } catch (e) {
      setError(formatApiErrorDetail(e.response?.data?.detail) || "Codice non valido");
      setDigits(Array(CODE_LENGTH).fill(""));
      inputsRef.current[0]?.focus();
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (idx, value) => {
    const v = value.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[idx] = v;
    setDigits(next);
    if (v && idx < CODE_LENGTH - 1) inputsRef.current[idx + 1]?.focus();
    if (next.every((d) => d !== "") && !submitting) submitCode(next.join(""));
  };

  const handleKeyDown = (idx, e) => {
    if (e.key === "Backspace" && !digits[idx] && idx > 0) {
      inputsRef.current[idx - 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    const paste = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, CODE_LENGTH);
    if (!paste) return;
    e.preventDefault();
    const arr = paste.split("").concat(Array(CODE_LENGTH).fill("")).slice(0, CODE_LENGTH);
    setDigits(arr);
    if (paste.length === CODE_LENGTH) submitCode(paste);
    else inputsRef.current[paste.length]?.focus();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const code = digits.join("");
    if (code.length === CODE_LENGTH) submitCode(code);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--sand)] relative overflow-hidden px-5">
      <div className="absolute inset-0 grain" />
      <div className="relative w-full max-w-md">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-[var(--warm-grey)] hover:text-[var(--espresso)] mb-6"
        >
          <ArrowLeft size={16} /> Torna al sito
        </Link>

        <div className="bg-white rounded-3xl p-8 md:p-10 shadow-[0_25px_60px_-30px_rgba(43,35,31,0.3)]">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 rounded-full bg-[var(--terracotta)] flex items-center justify-center text-[var(--cream)]">
              <PawPrint size={20} />
            </div>
            <div>
              <div className="font-serif-display text-xl font-semibold text-[var(--espresso)]">Roberta's</div>
              <div className="eyebrow -mt-0.5">Area Staff</div>
            </div>
          </div>

          <h1 className="font-serif-display text-3xl mt-6 text-[var(--espresso)] leading-tight">
            Inserisci il codice di accesso
          </h1>
          <p className="mt-2 text-sm text-[var(--warm-grey)]">
            Riservato al personale del salone.
          </p>

          <form onSubmit={handleSubmit} className="mt-8" data-testid="staff-login-form">
            <div
              className="flex justify-between gap-2 sm:gap-3"
              onPaste={handlePaste}
              data-testid="staff-code-inputs"
            >
              {digits.map((d, i) => (
                <input
                  key={CODE_SLOT_IDS[i]}
                  ref={(el) => (inputsRef.current[i] = el)}
                  data-testid={`staff-code-input-${i}`}
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={1}
                  value={d}
                  onChange={(e) => handleChange(i, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(i, e)}
                  disabled={submitting}
                  className="w-full aspect-square text-center font-serif-display text-3xl font-semibold bg-[var(--cream)] border border-[rgba(43,35,31,0.15)] rounded-xl focus:outline-none focus:border-[var(--terracotta)] focus:ring-2 focus:ring-[var(--terracotta)]/15 transition text-[var(--espresso)]"
                />
              ))}
            </div>

            {error && (
              <div data-testid="staff-login-error" className="mt-5 text-sm text-[#991B1B] bg-[#FEE2E2] rounded-xl px-4 py-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              data-testid="staff-login-submit-button"
              disabled={submitting || digits.some((d) => !d)}
              className="btn-primary w-full justify-center mt-6 disabled:opacity-50"
            >
              {submitting ? (
                <><Loader2 size={16} className="animate-spin" /> Verifica…</>
              ) : (
                "Accedi"
              )}
            </button>
          </form>
        </div>

        <p className="mt-6 text-xs text-center text-[var(--warm-grey)]">
          Problemi con l'accesso? Contatta l'amministratore.
        </p>
      </div>
    </div>
  );
}
