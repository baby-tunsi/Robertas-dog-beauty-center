import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { api, formatApiErrorDetail } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import {
  PawPrint, LogOut, CheckCircle2, XCircle, Phone, User, Calendar, Clock,
  Filter, Trash2, ShieldCheck, MessageSquare, Loader2, UserPlus,
} from "lucide-react";
import ManualBookingDialog from "@/components/ManualBookingDialog";

const STATUS_LABEL = {
  pending: "In attesa",
  confirmed: "Confermata",
  rejected: "Rifiutata",
};

function StatusBadge({ status }) {
  return (
    <span className={`status-pill status-${status}`} data-testid={`status-badge-${status}`}>
      {status === "pending" && <Clock size={12} />}
      {status === "confirmed" && <CheckCircle2 size={12} />}
      {status === "rejected" && <XCircle size={12} />}
      {STATUS_LABEL[status]}
    </span>
  );
}

function BookingCard({ b, onAction }) {
  const [expanded, setExpanded] = useState(b.status === "pending");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const handle = async (action) => {
    setBusy(true);
    try {
      if (action === "delete") {
        await api.delete(`/bookings/${b.id}`);
        toast.success("Prenotazione eliminata");
      } else {
        await api.post(`/bookings/${b.id}/${action}`, { staff_note: note || null });
        toast.success(action === "confirm" ? "Prenotazione confermata" : "Prenotazione rifiutata");
      }
      onAction();
    } catch (e) {
      toast.error(formatApiErrorDetail(e.response?.data?.detail) || "Errore");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      data-testid={`booking-card-${b.id}`}
      className="card-tactile p-6 md:p-7"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h3 className="font-serif-display text-xl font-semibold text-[var(--espresso)]">
              {b.first_name} {b.last_name}
            </h3>
            <StatusBadge status={b.status} />
          </div>
          <div className="mt-1 text-sm text-[var(--warm-grey)]">
            {b.service_name} · {b.preferred_date}
            {b.preferred_time && ` alle ${b.preferred_time}`}
          </div>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          data-testid={`booking-toggle-${b.id}`}
          className="text-xs font-semibold text-[var(--terracotta)] link-underline"
        >
          {expanded ? "Chiudi" : "Dettagli"}
        </button>
      </div>

      {expanded && (
        <div className="mt-6 space-y-5" data-testid={`booking-detail-${b.id}`}>
          <div
            data-testid="booking-verification-panel"
            className="rounded-2xl bg-[var(--sage-soft)] p-5 border border-[var(--sage)]/20"
          >
            <div className="flex items-center gap-2 eyebrow" style={{ color: "var(--sage)" }}>
              <ShieldCheck size={14} /> Verifica cliente
            </div>
            <div className="mt-4 grid sm:grid-cols-3 gap-4">
              <div>
                <div className="text-xs uppercase tracking-wider text-[var(--warm-grey)]">Nome</div>
                <div data-testid="verify-name-display" className="mt-1 font-semibold text-[var(--espresso)] flex items-center gap-1.5">
                  <User size={14} /> {b.first_name} {b.last_name}
                </div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-[var(--warm-grey)]">Telefono</div>
                <a
                  data-testid="verify-phone-display"
                  href={`tel:${b.phone}`}
                  className="mt-1 font-semibold text-[var(--terracotta)] flex items-center gap-1.5 hover:underline"
                >
                  <Phone size={14} /> {b.phone}
                </a>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-[var(--warm-grey)]">Prenotato il</div>
                <div className="mt-1 font-semibold text-[var(--espresso)] flex items-center gap-1.5">
                  <Calendar size={14} /> {new Date(b.created_at).toLocaleDateString("it-IT")}
                </div>
              </div>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="eyebrow">Cane</div>
              <div className="mt-1 text-[var(--espresso)]">
                {b.dog_name || "—"}
                {b.dog_breed && ` · ${b.dog_breed}`}
                {b.dog_size && ` · taglia ${b.dog_size}`}
              </div>
            </div>
            <div>
              <div className="eyebrow">Note del cliente</div>
              <div className="mt-1 text-[var(--warm-grey)]">{b.notes || "—"}</div>
            </div>
            {b.time_preference && (
              <div className="sm:col-span-2">
                <div className="eyebrow">Preferenza orario del cliente</div>
                <div className="mt-1 text-[var(--espresso)] italic">"{b.time_preference}"</div>
              </div>
            )}
          </div>

          {b.status === "pending" ? (
            <>
              <label className="block">
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--warm-grey)] flex items-center gap-1.5">
                  <MessageSquare size={12} /> Nota interna (opzionale)
                </span>
                <textarea
                  data-testid={`booking-staff-note-${b.id}`}
                  className="mt-2 w-full bg-[var(--cream)] border border-[rgba(43,35,31,0.12)] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[var(--terracotta)] min-h-[70px]"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="es. Confermato al telefono, tocletta corta"
                />
              </label>
              <div className="flex flex-wrap gap-3">
                <button
                  data-testid={`confirm-booking-button-${b.id}`}
                  onClick={() => handle("confirm")}
                  disabled={busy}
                  className="btn-primary disabled:opacity-50"
                >
                  {busy ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
                  Conferma prenotazione
                </button>
                <button
                  data-testid={`reject-booking-button-${b.id}`}
                  onClick={() => handle("reject")}
                  disabled={busy}
                  className="btn-ghost disabled:opacity-50"
                  style={{ color: "#991B1B", borderColor: "#FCA5A5" }}
                >
                  <XCircle size={16} /> Rifiuta
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[rgba(43,35,31,0.08)]">
              <div className="text-xs text-[var(--warm-grey)]">
                {b.verified_by && <>Gestito da <strong>{b.verified_by}</strong></>}
                {b.staff_note && <> · Nota: “{b.staff_note}”</>}
              </div>
              <button
                data-testid={`delete-booking-button-${b.id}`}
                onClick={() => handle("delete")}
                disabled={busy}
                className="text-xs text-[var(--warm-grey)] hover:text-[#991B1B] inline-flex items-center gap-1"
              >
                <Trash2 size={12} /> Elimina
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function StaffDashboard() {
  const { user, logout } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [stats, setStats] = useState({ pending: 0, confirmed: 0, rejected: 0, total: 0 });
  const [filter, setFilter] = useState("pending");
  const [loading, setLoading] = useState(true);
  const [manualOpen, setManualOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [list, statResp] = await Promise.all([
        api.get(`/bookings${filter !== "all" ? `?status=${filter}` : ""}`),
        api.get("/bookings/stats"),
      ]);
      setBookings(list.data);
      setStats(statResp.data);
    } catch (e) {
      toast.error("Errore caricamento prenotazioni");
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const FILTERS = [
    { id: "pending", label: `In attesa (${stats.pending})` },
    { id: "confirmed", label: `Confermate (${stats.confirmed})` },
    { id: "rejected", label: `Rifiutate (${stats.rejected})` },
    { id: "all", label: `Tutte (${stats.total})` },
  ];

  return (
    <div data-testid="staff-dashboard-container" className="min-h-screen bg-[var(--sand)]">
      <header className="glass-nav sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--terracotta)] flex items-center justify-center text-[var(--cream)]">
              <PawPrint size={20} />
            </div>
            <div className="leading-tight">
              <div className="font-serif-display text-lg font-semibold text-[var(--espresso)]">Roberta's</div>
              <div className="eyebrow -mt-0.5">Pannello Staff</div>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline text-sm text-[var(--warm-grey)]">
              Ciao, <strong data-testid="staff-user-name" className="text-[var(--espresso)]">{user?.name}</strong>
            </span>
            <button
              onClick={logout}
              data-testid="staff-logout-button"
              className="btn-ghost text-sm"
            >
              <LogOut size={14} /> Esci
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 sm:px-8 py-10 md:py-14">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="eyebrow">Prenotazioni</div>
            <h1 className="font-serif-display text-3xl md:text-5xl font-semibold text-[var(--espresso)] mt-3 leading-tight">
              Le richieste dei tuoi clienti.
            </h1>
            <p className="mt-3 text-[var(--warm-grey)] max-w-xl">
              Verifica nome, cognome e numero di telefono prima di confermare ogni appuntamento.
            </p>
          </div>
          <button
            data-testid="open-manual-booking"
            onClick={() => setManualOpen(true)}
            className="btn-primary"
          >
            <UserPlus size={16} /> Nuova prenotazione manuale
          </button>
        </div>

        <ManualBookingDialog
          open={manualOpen}
          onClose={() => setManualOpen(false)}
          onCreated={load}
        />

        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { k: "pending", label: "In attesa", val: stats.pending, color: "#F59E0B" },
            { k: "confirmed", label: "Confermate", val: stats.confirmed, color: "#059669" },
            { k: "rejected", label: "Rifiutate", val: stats.rejected, color: "#DC2626" },
            { k: "total", label: "Totali", val: stats.total, color: "var(--espresso)" },
          ].map((c) => (
            <div
              key={c.k}
              data-testid={`stat-${c.k}`}
              className="bg-white rounded-2xl p-5 border border-[rgba(43,35,31,0.08)]"
            >
              <div className="text-xs uppercase tracking-wider text-[var(--warm-grey)] font-semibold">{c.label}</div>
              <div className="font-serif-display text-4xl font-semibold mt-2" style={{ color: c.color }}>
                {c.val}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12">
          <div className="eyebrow">Prenotazioni ricevute</div>
          <h2 className="font-serif-display text-2xl md:text-3xl font-semibold text-[var(--espresso)] mt-2">
            Lista richieste
          </h2>
        </div>

        <div className="mt-6 flex items-center gap-3 flex-wrap">
          <Filter size={14} className="text-[var(--warm-grey)]" />
          {FILTERS.map((f) => (
            <button
              key={f.id}
              data-testid={`filter-${f.id}`}
              onClick={() => setFilter(f.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                filter === f.id
                  ? "bg-[var(--espresso)] text-[var(--cream)]"
                  : "bg-white text-[var(--warm-grey)] hover:text-[var(--espresso)] border border-[rgba(43,35,31,0.08)]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="mt-8 space-y-4">
          {loading ? (
            <div className="text-center py-16 text-[var(--warm-grey)]">
              <Loader2 className="animate-spin mx-auto" />
              <p className="mt-3 text-sm">Caricamento…</p>
            </div>
          ) : bookings.length === 0 ? (
            <div
              data-testid="empty-bookings"
              className="bg-white rounded-3xl p-12 text-center border border-[rgba(43,35,31,0.08)]"
            >
              <PawPrint className="mx-auto text-[var(--sage)]" size={40} />
              <h3 className="mt-4 font-serif-display text-2xl text-[var(--espresso)]">Nessuna prenotazione</h3>
              <p className="mt-2 text-sm text-[var(--warm-grey)]">
                Non ci sono prenotazioni con questo stato al momento.
              </p>
            </div>
          ) : (
            bookings.map((b) => <BookingCard key={b.id} b={b} onAction={load} />)
          )}
        </div>
      </main>
    </div>
  );
}
