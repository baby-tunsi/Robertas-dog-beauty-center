import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import BookingForm from "@/components/BookingForm";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function HomePage() {
  const [selectedService, setSelectedService] = useState(null);

  const handleServiceSelect = (id) => {
    setSelectedService(id);
    setTimeout(() => {
      document.getElementById("prenota")?.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };

  return (
    <div data-testid="home-page" className="bg-[var(--cream)]">
      <Header />
      <Hero />
      <Services onSelectService={handleServiceSelect} />
      <About />
      <BookingForm initialService={selectedService} />
      <Contact />
      <Footer />
    </div>
  );
}
